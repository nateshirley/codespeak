# FlatTypeDefinition = Union[BuiltinType, LocalClassType, InstalledClassType, GenericType]
