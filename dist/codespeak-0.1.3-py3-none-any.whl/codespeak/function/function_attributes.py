class FunctionAttributes:
    frame = "_frame"
    logic = "_logic"
    declaration = "_declaration"
    file_service = "_file_service"
    is_prod = "_is_prod"
