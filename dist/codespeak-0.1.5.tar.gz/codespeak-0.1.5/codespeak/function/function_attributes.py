class FunctionAttributes:
    frame = "_frame"
    logic = "_logic"
    declaration = "_declaration"
    file_service = "_file_service"
    is_dev = "_is_dev"
