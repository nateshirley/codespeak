from typing import TypeVar


T = TypeVar("T")


def example(item: T) -> T:
    return item
