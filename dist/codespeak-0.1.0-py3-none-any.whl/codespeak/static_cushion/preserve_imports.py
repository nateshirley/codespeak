def preserve(*args):
    _ = args
    return None
