# codespeak/inferences (is what it should be)
codespeak_dirname = "_codespeak"
inferences_dirname = "inferences"
metadata_file_prefix = "_metadata_"
