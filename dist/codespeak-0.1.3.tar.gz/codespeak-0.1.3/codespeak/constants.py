codegen_dirname = "codespeak_inferences"
metadata_file_prefix = "_metadata_"
